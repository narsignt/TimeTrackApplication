<?php
//echo $_SERVER['HTTP_HOST'];

	if ($_SERVER['SERVER_NAME'] =="italentcorp.biz"){

		$ipaddress ="dtimetracker.db.12054818.hostedresource.com";
		$dbusername="dtimetracker";
		$dbpassword="Q!w2e3r4";
		$dbname="dtimetracker";

	}elseif($_SERVER['SERVER_NAME'] =="iappease.com"){
		$ipaddress ="68.178.217.5";
		$dbusername="italentnewdb";
		$dbpassword="Q!w2e3r4";
		$dbname="italentnewdb";
	}
?>
